# James-favour Portfolio
This repository will contain my Data Science Projects Portfolio, the template used is Massively which was downloaded from HTML5 UP, the template was edited using Visual studio Code.
